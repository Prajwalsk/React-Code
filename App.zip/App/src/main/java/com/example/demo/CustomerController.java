package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins="localhost:3000")
@RequestMapping("/mmp")
public class CustomerController {

	@Autowired
	private CustomerSservice service;
   @PostMapping("/insert")
	public CustomerModel reg(@RequestBody CustomerModel cmd) {
		return service.register(cmd);
	}

}
