package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class CustomerDao {
	@Autowired
	private CustmerRepositry rep;

	public CustomerModel save(CustomerModel cmd) {
		return rep.save(cmd);
	}

}
