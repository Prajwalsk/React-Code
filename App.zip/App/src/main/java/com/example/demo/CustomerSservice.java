package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

@Service
public class CustomerSservice {
	@Autowired
	private CustomerDao dao;

	public CustomerModel register(CustomerModel model) {
		return dao.save(model);
	
	}
	public ModelAndView mode(ModelAndView view ,CustomerModel model) {
		 
		
		return null;
	}
	
}
